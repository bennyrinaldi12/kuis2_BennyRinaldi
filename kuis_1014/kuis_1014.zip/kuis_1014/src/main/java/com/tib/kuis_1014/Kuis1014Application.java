package com.tib.kuis_1014;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kuis1014Application {

	public static void main(String[] args) {
		SpringApplication.run(Kuis1014Application.class, args);
	}
}
